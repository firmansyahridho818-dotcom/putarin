package com.example.puterinapp

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// --- HOME SCREEN ---
@Composable
fun HomeScreen(products: List<Product>, onProductClick: (Product) -> Unit) {
    var searchQuery by remember { mutableStateOf("") }

    val filteredProducts = if (searchQuery.isEmpty()) {
        products
    } else {
        products.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
                    it.description.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(modifier = Modifier.padding(16.dp)) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Cari barang bekas...") },
            modifier = Modifier.fillMaxWidth(),
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            shape = MaterialTheme.shapes.medium
        )

        Spacer(modifier = Modifier.height(16.dp))
        Text("Rekomendasi", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(modifier = Modifier.height(8.dp))

        if (filteredProducts.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("Tidak ada produk ditemukan", color = Color.Gray)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredProducts) { product ->
                    ProductCard(product, onClick = { onProductClick(product) })
                }
            }
        }
    }
}

@Composable
fun ProductCard(product: Product, onClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(4.dp),
        modifier = Modifier.clickable { onClick() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                modifier = Modifier.size(100.dp),
                color = Color.LightGray,
                shape = MaterialTheme.shapes.small
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = Color.Gray)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(product.name, fontWeight = FontWeight.Medium, maxLines = 1)
            Text(product.price, color = Color(0xFF1E3A8A), fontWeight = FontWeight.Bold)

            val avgRating = if (product.reviews.isNotEmpty()) {
                product.reviews.map { it.rating }.average()
            } else 0.0

            if (product.reviews.isNotEmpty()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Star,
                        contentDescription = null,
                        tint = Color(0xFFFFA000),
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        "${String.format("%.1f", avgRating)} (${product.reviews.size})",
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                }
            }
        }
    }
}

// --- PRODUCT DETAIL SCREEN ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductDetailScreen(product: Product, currentUser: User, onBack: () -> Unit) {
    val context = LocalContext.current
    var newReview by remember { mutableStateOf("") }
    var newRating by remember { mutableStateOf(5) }

    // Load reviews from database
    val reviews = remember { mutableStateListOf<Review>() }

    LaunchedEffect(product.id) {
        reviews.clear()
        reviews.addAll(DatabaseHelper.getProductReviews(product.id))
    }

    val avgRating = if (reviews.isNotEmpty()) {
        reviews.map { it.rating }.average()
    } else 0.0

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Detail Barang") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1E3A8A),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(250.dp)
                        .background(Color.LightGray),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.ShoppingCart,
                        contentDescription = null,
                        modifier = Modifier.size(100.dp),
                        tint = Color.Gray
                    )
                }
            }

            item {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(product.name, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        product.price,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E3A8A)
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    Surface(
                        color = Color(0xFFE8F5E9),
                        shape = MaterialTheme.shapes.small
                    ) {
                        Text(
                            product.condition,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            color = Color(0xFF2E7D32),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    if (reviews.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            repeat(5) { index ->
                                Icon(
                                    Icons.Default.Star,
                                    contentDescription = null,
                                    tint = if (index < avgRating.toInt()) Color(0xFFFFA000) else Color.LightGray,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "${String.format("%.1f", avgRating)} dari ${reviews.size} review",
                                fontSize = 14.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(16.dp))

                    Text("Deskripsi", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(product.description, color = Color.Gray, lineHeight = 22.sp)

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(16.dp))

                    Text("Penjual", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            modifier = Modifier.size(48.dp),
                            shape = CircleShape,
                            color = Color(0xFF1E3A8A)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = Color.White)
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(product.seller, fontWeight = FontWeight.Medium)
                            Text(product.sellerPhone, fontSize = 12.sp, color = Color.Gray)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Review", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("(${reviews.size})", color = Color.Gray)
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }

            items(reviews) { review ->
                ReviewItem(review)
            }

            item {
                Column(modifier = Modifier.padding(16.dp)) {
                    Divider()
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Tulis Review", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Rating:", modifier = Modifier.width(80.dp))
                        repeat(5) { index ->
                            IconButton(onClick = { newRating = index + 1 }) {
                                Icon(
                                    Icons.Default.Star,
                                    contentDescription = null,
                                    tint = if (index < newRating) Color(0xFFFFA000) else Color.LightGray
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newReview,
                        onValueChange = { newReview = it },
                        label = { Text("Komentar Anda") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 4,
                        minLines = 3
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            if (newReview.isNotEmpty()) {
                                DatabaseHelper.addReview(
                                    productId = product.id,
                                    userName = currentUser.name,
                                    rating = newRating,
                                    comment = newReview
                                )

                                reviews.clear()
                                reviews.addAll(DatabaseHelper.getProductReviews(product.id))

                                Toast.makeText(context, "Review berhasil dikirim!", Toast.LENGTH_SHORT).show()
                                newReview = ""
                                newRating = 5
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488))
                    ) {
                        Text("Kirim Review")
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }

            item {
                Button(
                    onClick = {
                        val message = "Halo, saya tertarik dengan ${product.name} seharga ${product.price}"
                        val intent = Intent(Intent.ACTION_VIEW).apply {
                            data = Uri.parse("https://wa.me/${product.sellerPhone}?text=${Uri.encode(message)}")
                        }
                        context.startActivity(intent)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                ) {
                    Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Beli via WhatsApp", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ReviewItem(review: Review) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        modifier = Modifier.size(32.dp),
                        shape = CircleShape,
                        color = Color(0xFF1E3A8A)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                review.userName.first().toString(),
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(review.userName, fontWeight = FontWeight.Medium)
                }
                Row {
                    repeat(review.rating) {
                        Icon(
                            Icons.Default.Star,
                            contentDescription = null,
                            tint = Color(0xFFFFA000),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(review.comment, fontSize = 14.sp, color = Color.DarkGray)
            Spacer(modifier = Modifier.height(4.dp))
            Text(review.date, fontSize = 11.sp, color = Color.Gray)
        }
    }
}

// --- JUAL SCREEN ---
@Composable
fun JualScreen(currentUser: User, onProductAdded: (Product) -> Unit) {
    val context = LocalContext.current
    var judul by remember { mutableStateOf("") }
    var harga by remember { mutableStateOf("") }
    var deskripsi by remember { mutableStateOf("") }
    var kondisi by remember { mutableStateOf("Bekas - Baik") }
    var nomorWA by remember { mutableStateOf(currentUser.phone) }
    var showImagePlaceholder by remember { mutableStateOf(true) }
    var showError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    if (showError) {
        AlertDialog(
            onDismissRequest = { showError = false },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFFFA000)) },
            title = { Text("Perhatian!") },
            text = { Text(errorMessage) },
            confirmButton = {
                TextButton(onClick = { showError = false }) {
                    Text("OK")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            "Jual Barang Bekas",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1E3A8A)
        )
        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
                .clickable {
                    showImagePlaceholder = false
                    Toast.makeText(context, "Foto berhasil diupload", Toast.LENGTH_SHORT).show()
                },
            colors = CardDefaults.cardColors(
                containerColor = if (showImagePlaceholder) Color(0xFFF3F4F6) else Color(0xFFE8F5E9)
            )
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    if (showImagePlaceholder) Icons.Default.Add else Icons.Default.CheckCircle,
                    contentDescription = null,
                    modifier = Modifier.size(40.dp),
                    tint = if (showImagePlaceholder) Color.Gray else Color(0xFF2E7D32)
                )
                Text(
                    if (showImagePlaceholder) "Tap untuk upload foto" else "Foto berhasil diupload",
                    color = if (showImagePlaceholder) Color.Gray else Color(0xFF2E7D32)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = judul,
            onValueChange = { judul = it },
            label = { Text("Judul Barang") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = harga,
            onValueChange = { harga = it },
            label = { Text("Harga (Rp)") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))

        var expanded by remember { mutableStateOf(false) }
        val kondisiOptions = listOf("Bekas - Seperti Baru", "Bekas - Sangat Baik", "Bekas - Baik")

        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = { expanded = !expanded }
        ) {
            OutlinedTextField(
                value = kondisi,
                onValueChange = {},
                readOnly = true,
                label = { Text("Kondisi Barang") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                modifier = Modifier
                    .fillMaxWidth()
                    .menuAnchor()
            )
            ExposedDropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                kondisiOptions.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option) },
                        onClick = {
                            kondisi = option
                            expanded = false
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = nomorWA,
            onValueChange = { nomorWA = it },
            label = { Text("Nomor WhatsApp (08xxx)") },
            modifier = Modifier.fillMaxWidth(),
            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) }
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = deskripsi,
            onValueChange = { deskripsi = it },
            label = { Text("Deskripsi") },
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp),
            maxLines = 5
        )
        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = {
                when {
                    judul.isEmpty() -> {
                        errorMessage = "Judul barang harus diisi!"
                        showError = true
                    }
                    harga.isEmpty() -> {
                        errorMessage = "Harga harus diisi!"
                        showError = true
                    }
                    deskripsi.isEmpty() -> {
                        errorMessage = "Deskripsi harus diisi!"
                        showError = true
                    }
                    nomorWA.isEmpty() || !nomorWA.startsWith("08") -> {
                        errorMessage = "Nomor WhatsApp harus diisi dan diawali dengan 08!"
                        showError = true
                    }
                    showImagePlaceholder -> {
                        errorMessage = "Upload foto barang terlebih dahulu!"
                        showError = true
                    }
                    else -> {
                        val priceFormatted = if (harga.startsWith("Rp")) harga else "Rp $harga"

                        val productId = DatabaseHelper.addProduct(
                            name = judul,
                            price = priceFormatted,
                            description = deskripsi,
                            condition = kondisi,
                            seller = currentUser.name,
                            sellerPhone = nomorWA
                        )

                        if (productId > 0) {
                            val newProduct = Product(
                                id = productId.toInt(),
                                name = judul,
                                price = priceFormatted,
                                description = deskripsi,
                                condition = kondisi,
                                seller = currentUser.name,
                                sellerPhone = nomorWA,
                                reviews = mutableListOf()
                            )
                            onProductAdded(newProduct)
                            Toast.makeText(context, "Barang berhasil ditayangkan!", Toast.LENGTH_SHORT).show()

                            judul = ""
                            harga = ""
                            deskripsi = ""
                            kondisi = "Bekas - Baik"
                            nomorWA = currentUser.phone
                            showImagePlaceholder = true
                        }
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488))
        ) {
            Text("Tayangkan Iklan")
        }
    }
}

// Continue to Donasi screens in next artifact...