
package com.example.puterinapp

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// --- DONASI SCREEN ---
@Composable
fun DonasiScreen(
    donationPlaces: MutableList<DonationPlace>,
    onAddPlace: (DonationPlace) -> Unit
) {
    var selectedPlace by remember { mutableStateOf<DonationPlace?>(null) }
    var showRegisterForm by remember { mutableStateOf(false) }
    val context = LocalContext.current

    when {
        showRegisterForm -> {
            RegisterDonationReceiverScreen(
                onBack = { showRegisterForm = false },
                onSubmit = { newPlace ->
                    onAddPlace(newPlace)
                    showRegisterForm = false
                    Toast.makeText(
                        context,
                        "Pendaftaran berhasil! Tempat donasi telah ditambahkan.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            )
        }
        selectedPlace != null -> {
            DonasiFormContent(
                place = selectedPlace!!,
                onBack = { selectedPlace = null }
            )
        }
        else -> {
            DonasiListContent(
                places = donationPlaces,
                onItemClick = { place -> selectedPlace = place },
                onRegisterClick = { showRegisterForm = true }
            )
        }
    }
}

// --- REGISTER DONATION RECEIVER ---
@Composable
fun RegisterDonationReceiverScreen(
    onBack: () -> Unit,
    onSubmit: (DonationPlace) -> Unit
) {
    var namaLembaga by remember { mutableStateOf("") }
    var alamat by remember { mutableStateOf("") }
    var noHp by remember { mutableStateOf("") }
    var deskripsi by remember { mutableStateOf("") }
    var kategori by remember { mutableStateOf("Panti Asuhan") }
    var showError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    val kategoriOptions = listOf(
        "Panti Asuhan",
        "Yayasan",
        "Posko Bencana",
        "Masjid/Gereja",
        "Lainnya"
    )
    var expanded by remember { mutableStateOf(false) }
    val context = LocalContext.current

    if (showError) {
        AlertDialog(
            onDismissRequest = { showError = false },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFFFA000)) },
            title = { Text("Perhatian!") },
            text = { Text(errorMessage) },
            confirmButton = {
                TextButton(onClick = { showError = false }) {
                    Text("OK")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1E3A8A))
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Text(
                    "Daftar Sebagai Penerima Donasi",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                "Informasi Lembaga/Tempat Penerima Donasi",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = Color(0xFF1E3A8A)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "Lengkapi data di bawah ini agar dapat menerima donasi barang bekas dari pengguna puter.in",
                fontSize = 12.sp,
                color = Color.Gray,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(24.dp))

            OutlinedTextField(
                value = namaLembaga,
                onValueChange = { namaLembaga = it },
                label = { Text("Nama Lembaga/Tempat") },
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Default.Home, contentDescription = null) }
            )
            Spacer(modifier = Modifier.height(12.dp))

            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = { expanded = !expanded }
            ) {
                OutlinedTextField(
                    value = kategori,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Kategori") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    leadingIcon = { Icon(Icons.Default.List, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .menuAnchor()
                )
                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    kategoriOptions.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option) },
                            onClick = {
                                kategori = option
                                expanded = false
                            }
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = alamat,
                onValueChange = { alamat = it },
                label = { Text("Alamat Lengkap") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 3,
                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) }
            )
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = noHp,
                onValueChange = { noHp = it },
                label = { Text("Nomor HP/WhatsApp (08xxx)") },
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) }
            )
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = deskripsi,
                onValueChange = { deskripsi = it },
                label = { Text("Deskripsi Singkat") },
                placeholder = { Text("Contoh: Membutuhkan donasi pakaian, buku, dan mainan anak") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 4,
                minLines = 3,
                leadingIcon = { Icon(Icons.Default.Info, contentDescription = null) }
            )

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF9C4))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Info,
                        contentDescription = null,
                        tint = Color(0xFFF57F17),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        "Data Anda akan ditampilkan di aplikasi agar pengguna dapat mendonasikan barang bekas mereka.",
                        fontSize = 12.sp,
                        color = Color(0xFF795548)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    when {
                        namaLembaga.isEmpty() -> {
                            errorMessage = "Nama lembaga harus diisi!"
                            showError = true
                        }
                        alamat.isEmpty() -> {
                            errorMessage = "Alamat harus diisi!"
                            showError = true
                        }
                        noHp.isEmpty() || !noHp.startsWith("08") -> {
                            errorMessage = "Nomor HP harus diisi dan diawali dengan 08!"
                            showError = true
                        }
                        else -> {
                            val placeId = DatabaseHelper.addDonationPlace(
                                name = namaLembaga,
                                description = deskripsi.ifEmpty { "$kategori - $alamat" },
                                address = alamat,
                                phone = noHp,
                                category = kategori
                            )

                            if (placeId > 0) {
                                val colors = listOf(
                                    Color(0xFFE57373), Color(0xFF81C784), Color(0xFF64B5F6),
                                    Color(0xFFFFD54F), Color(0xFFBA68C8), Color(0xFFFF8A65)
                                )
                                val newPlace = DonationPlace(
                                    id = placeId.toInt(),
                                    name = namaLembaga,
                                    description = deskripsi.ifEmpty { "$kategori - ${alamat.take(30)}" },
                                    imageColor = colors.random(),
                                    address = alamat,
                                    phone = noHp,
                                    category = kategori
                                )
                                onSubmit(newPlace)
                            }
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A))
            ) {
                Text("Daftar Sekarang", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

// --- DONASI LIST ---
@Composable
fun DonasiListContent(
    places: List<DonationPlace>,
    onItemClick: (DonationPlace) -> Unit,
    onRegisterClick: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1E3A8A))
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "Pilih Tujuan Donasi",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .clickable { onRegisterClick() },
            colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.AddCircle,
                    contentDescription = null,
                    tint = Color(0xFF2E7D32),
                    modifier = Modifier.size(40.dp)
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        "Daftar Sebagai Penerima Donasi",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color(0xFF2E7D32)
                    )
                    Text(
                        "Klik di sini untuk mendaftarkan lembaga/tempat Anda",
                        fontSize = 12.sp,
                        color = Color(0xFF558B2F)
                    )
                }
            }
        }

        Text(
            "Tempat Penerima Donasi",
            modifier = Modifier.padding(horizontal = 16.dp),
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        if (places.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("Belum ada tempat donasi terdaftar", color = Color.Gray)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(places) { place ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(100.dp)
                                    .background(place.imageColor),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Home,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(40.dp)
                                )
                            }

                            Column(
                                modifier = Modifier.padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    place.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    maxLines = 2
                                )
                                Text(
                                    place.description,
                                    fontSize = 12.sp,
                                    color = Color.Gray,
                                    maxLines = 1
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = { onItemClick(place) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF1E3A8A)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(36.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text("Donasi", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- DONASI FORM ---
@Composable
fun DonasiFormContent(place: DonationPlace, onBack: () -> Unit) {
    val context = LocalContext.current
    var nama by remember { mutableStateOf("") }
    var noHp by remember { mutableStateOf("") }
    var alamat by remember { mutableStateOf("") }
    var showImagePlaceholder by remember { mutableStateOf(true) }
    var showError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    if (showError) {
        AlertDialog(
            onDismissRequest = { showError = false },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFFFA000)) },
            title = { Text("Perhatian!") },
            text = { Text(errorMessage) },
            confirmButton = {
                TextButton(onClick = { showError = false }) {
                    Text("OK")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1E3A8A))
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Text(
                    "Konfirmasi Pengiriman",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Column(modifier = Modifier.padding(20.dp)) {
            Text("Tujuan Donasi:", color = Color.Gray, fontSize = 12.sp)
            Text(
                place.name,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = Color(0xFF1E3A8A)
            )
            Text(place.address, fontSize = 12.sp, color = Color.Gray)
            Spacer(modifier = Modifier.height(24.dp))

            Text("Data Pengirim Donasi", fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = nama,
                onValueChange = { nama = it },
                label = { Text("Nama Lengkap") },
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
            )
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = noHp,
                onValueChange = { noHp = it },
                label = { Text("Nomor HP / WA (08xxx)") },
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) }
            )
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = alamat,
                onValueChange = { alamat = it },
                label = { Text("Alamat Pengambilan") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 3,
                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) }
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text("Foto Barang Donasi", fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .background(
                        if (showImagePlaceholder) Color(0xFFF0F0F0) else Color(0xFFE8F5E9),
                        shape = MaterialTheme.shapes.medium
                    )
                    .clickable {
                        showImagePlaceholder = false
                        Toast
                            .makeText(context, "Foto berhasil diupload", Toast.LENGTH_SHORT)
                            .show()
                    }
                    .padding(2.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        if (showImagePlaceholder) Icons.Default.Add else Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = if (showImagePlaceholder) Color.Gray else Color(0xFF2E7D32),
                        modifier = Modifier.size(40.dp)
                    )
                    Text(
                        if (showImagePlaceholder) "Tap untuk upload foto barang" else "Foto berhasil diupload",
                        color = if (showImagePlaceholder) Color.Gray else Color(0xFF2E7D32),
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = {
                    when {
                        nama.isEmpty() -> {
                            errorMessage = "Nama lengkap harus diisi!"
                            showError = true
                        }
                        noHp.isEmpty() || !noHp.startsWith("08") -> {
                            errorMessage = "Nomor HP harus diisi dan diawali dengan 08!"
                            showError = true
                        }
                        alamat.isEmpty() -> {
                            errorMessage = "Alamat pengambilan harus diisi!"
                            showError = true
                        }
                        showImagePlaceholder -> {
                            errorMessage = "Upload foto barang donasi terlebih dahulu!"
                            showError = true
                        }
                        else -> {
                            val message = "Halo, saya $nama ingin mendonasikan barang. Alamat pengambilan: $alamat. Nomor saya: $noHp"
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                data = Uri.parse("https://wa.me/${place.phone}?text=${Uri.encode(message)}")
                            }
                            context.startActivity(intent)
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
            ) {
                Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Donasikan via WhatsApp", fontWeight = FontWeight.Bold)
            }
        }
    }
}