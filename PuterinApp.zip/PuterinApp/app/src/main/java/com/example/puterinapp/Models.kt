package com.example.puterinapp



import androidx.compose.ui.graphics.Color

// --- DATA MODELS ---

data class User(
    val id: Int = 0,
    val name: String,
    val email: String,
    val password: String = "",
    val phone: String,
    val address: String,
    val joinDate: String
)

data class Product(
    val id: Int,
    val name: String,
    val price: String,
    val description: String,
    val condition: String,
    val seller: String,
    val sellerPhone: String,
    val reviews: MutableList<Review> = mutableListOf()
)

data class Review(
    val id: Int = 0,
    val productId: Int = 0,
    val userName: String,
    val rating: Int,
    val comment: String,
    val date: String
)

data class DonationPlace(
    val id: Int = 0,
    val name: String,
    val description: String,
    val imageColor: Color,
    val address: String = "",
    val phone: String = "",
    val category: String = "Lainnya"
)