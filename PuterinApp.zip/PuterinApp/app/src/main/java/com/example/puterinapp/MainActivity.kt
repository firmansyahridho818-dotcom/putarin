package com.example.puterinapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize database
        DatabaseHelper.init(this)

        setContent {
            PuterinAppTheme {
                AppNavigation()
            }
        }
    }
}

// --- NAVIGATION ---
@Composable
fun AppNavigation() {
    var isLoggedIn by remember { mutableStateOf(false) }
    var currentUser by remember { mutableStateOf<User?>(null) }

    if (!isLoggedIn) {
        LoginScreen(
            onLoginSuccess = { user ->
                currentUser = user
                isLoggedIn = true
            }
        )
    } else {
        MainScreen(
            currentUser = currentUser!!,
            onLogout = {
                isLoggedIn = false
                currentUser = null
            }
        )
    }
}

// --- LOGIN SCREEN ---
@Composable
fun LoginScreen(onLoginSuccess: (User) -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isRegister by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var showError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var showForgotPassword by remember { mutableStateOf(false) }
    var passwordVisible by remember { mutableStateOf(false) }

    val context = LocalContext.current

    if (showForgotPassword) {
        ForgotPasswordDialog(
            onDismiss = { showForgotPassword = false },
            onSuccess = {
                showForgotPassword = false
                Toast.makeText(context, "Password berhasil diubah!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    if (showError) {
        AlertDialog(
            onDismissRequest = { showError = false },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = Color.Red) },
            title = { Text("Gagal!") },
            text = { Text(errorMessage) },
            confirmButton = {
                TextButton(onClick = { showError = false }) {
                    Text("OK")
                }
            }
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1E3A8A))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                Icons.Default.ShoppingCart,
                contentDescription = null,
                modifier = Modifier.size(80.dp),
                tint = Color.White
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "puter.in",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                "Jual Beli Barang Bekas",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(48.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        if (isRegister) "Daftar Akun" else "Masuk",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E3A8A)
                    )
                    Spacer(modifier = Modifier.height(24.dp))

                    if (isRegister) {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("Nama Lengkap") },
                            modifier = Modifier.fillMaxWidth(),
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("Nomor HP (08xxx)") },
                            modifier = Modifier.fillMaxWidth(),
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) }
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = address,
                            onValueChange = { address = it },
                            label = { Text("Alamat") },
                            modifier = Modifier.fillMaxWidth(),
                            leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                            maxLines = 2
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email") },
                        modifier = Modifier.fillMaxWidth(),
                        leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) }
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password") },
                        modifier = Modifier.fillMaxWidth(),
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = null
                                )
                            }
                        }
                    )

                    if (!isRegister) {
                        Spacer(modifier = Modifier.height(8.dp))
                        TextButton(
                            onClick = { showForgotPassword = true },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text("Lupa Password?", color = Color(0xFF1E3A8A), fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = {
                            if (isRegister) {
                                // Validasi pendaftaran
                                if (name.isEmpty() || email.isEmpty() || password.isEmpty() || phone.isEmpty() || address.isEmpty()) {
                                    errorMessage = "Semua field harus diisi!"
                                    showError = true
                                } else if (!email.contains("@")) {
                                    errorMessage = "Format email tidak valid!"
                                    showError = true
                                } else if (password.length < 6) {
                                    errorMessage = "Password minimal 6 karakter!"
                                    showError = true
                                } else if (!phone.startsWith("08")) {
                                    errorMessage = "Nomor HP harus diawali dengan 08"
                                    showError = true
                                } else {
                                    val result = DatabaseHelper.registerUser(name, email, password, phone, address)
                                    if (result) {
                                        val user = DatabaseHelper.loginUser(email, password)
                                        if (user != null) {
                                            onLoginSuccess(user)
                                        }
                                    } else {
                                        errorMessage = "Email sudah terdaftar!"
                                        showError = true
                                    }
                                }
                            } else {
                                // Validasi login
                                if (email.isEmpty() || password.isEmpty()) {
                                    errorMessage = "Email dan password harus diisi!"
                                    showError = true
                                } else {
                                    val user = DatabaseHelper.loginUser(email, password)
                                    if (user != null) {
                                        onLoginSuccess(user)
                                    } else {
                                        errorMessage = "Email atau password salah!"
                                        showError = true
                                    }
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488))
                    ) {
                        Text(if (isRegister) "Daftar" else "Masuk", fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    TextButton(
                        onClick = {
                            isRegister = !isRegister
                            // Reset fields
                            email = ""
                            password = ""
                            name = ""
                            phone = ""
                            address = ""
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            if (isRegister) "Sudah punya akun? Masuk" else "Belum punya akun? Daftar",
                            color = Color(0xFF1E3A8A)
                        )
                    }
                }
            }
        }
    }
}

// --- FORGOT PASSWORD DIALOG ---
@Composable
fun ForgotPasswordDialog(onDismiss: () -> Unit, onSuccess: () -> Unit) {
    var step by remember { mutableStateOf(1) } // 1: email, 2: otp, 3: new password
    var email by remember { mutableStateOf("") }
    var otp by remember { mutableStateOf("") }
    var generatedOtp by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    "Lupa Password",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E3A8A)
                )
                Spacer(modifier = Modifier.height(16.dp))

                when (step) {
                    1 -> {
                        Text("Masukkan email terdaftar Anda:", fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = email,
                            onValueChange = { email = it },
                            label = { Text("Email") },
                            modifier = Modifier.fillMaxWidth(),
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) }
                        )
                        if (errorMsg.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(errorMsg, color = Color.Red, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = onDismiss) {
                                Text("Batal")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (DatabaseHelper.checkEmailExists(email)) {
                                        generatedOtp = (100000..999999).random().toString()
                                        scope.launch {
                                            Toast.makeText(context, "Kode OTP: $generatedOtp (Simulasi)", Toast.LENGTH_LONG).show()
                                        }
                                        step = 2
                                        errorMsg = ""
                                    } else {
                                        errorMsg = "Email tidak terdaftar!"
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488))
                            ) {
                                Text("Kirim OTP")
                            }
                        }
                    }
                    2 -> {
                        Text("Masukkan kode OTP yang dikirim ke email:", fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("(Simulasi: $generatedOtp)", fontSize = 11.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = otp,
                            onValueChange = { otp = it },
                            label = { Text("Kode OTP") },
                            modifier = Modifier.fillMaxWidth(),
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) }
                        )
                        if (errorMsg.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(errorMsg, color = Color.Red, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { step = 1 }) {
                                Text("Kembali")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (otp == generatedOtp) {
                                        step = 3
                                        errorMsg = ""
                                    } else {
                                        errorMsg = "Kode OTP salah!"
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488))
                            ) {
                                Text("Verifikasi")
                            }
                        }
                    }
                    3 -> {
                        Text("Buat password baru:", fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = newPassword,
                            onValueChange = { newPassword = it },
                            label = { Text("Password Baru") },
                            modifier = Modifier.fillMaxWidth(),
                            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                            trailingIcon = {
                                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                    Icon(
                                        if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = null
                                    )
                                }
                            }
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = confirmPassword,
                            onValueChange = { confirmPassword = it },
                            label = { Text("Konfirmasi Password") },
                            modifier = Modifier.fillMaxWidth(),
                            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) }
                        )
                        if (errorMsg.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(errorMsg, color = Color.Red, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = onDismiss) {
                                Text("Batal")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (newPassword.length < 6) {
                                        errorMsg = "Password minimal 6 karakter!"
                                    } else if (newPassword != confirmPassword) {
                                        errorMsg = "Password tidak cocok!"
                                    } else {
                                        DatabaseHelper.updatePassword(email, newPassword)
                                        onSuccess()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488))
                            ) {
                                Text("Simpan")
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- MAIN SCREEN ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(currentUser: User, onLogout: () -> Unit) {
    var currentScreen by remember { mutableStateOf("home") }
    var selectedProduct by remember { mutableStateOf<Product?>(null) }

    // Load products from database
    val products = remember { mutableStateListOf<Product>() }
    val donationPlaces = remember { mutableStateListOf<DonationPlace>() }

    LaunchedEffect(Unit) {
        products.clear()
        products.addAll(DatabaseHelper.getAllProducts())
        donationPlaces.clear()
        donationPlaces.addAll(DatabaseHelper.getAllDonationPlaces())
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("puter.in", fontWeight = FontWeight.Bold, color = Color.White) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color(0xFF1E3A8A)
                )
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") },
                    selected = currentScreen == "home",
                    onClick = {
                        currentScreen = "home"
                        selectedProduct = null
                    }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Favorite, contentDescription = "Donasi") },
                    label = { Text("Donasi") },
                    selected = currentScreen == "donasi",
                    onClick = { currentScreen = "donasi" }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.AddCircle, contentDescription = "Jual") },
                    label = { Text("Jual") },
                    selected = currentScreen == "jual",
                    onClick = { currentScreen = "jual" }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Person, contentDescription = "Akun") },
                    label = { Text("Akun") },
                    selected = currentScreen == "akun",
                    onClick = { currentScreen = "akun" }
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when {
                selectedProduct != null -> ProductDetailScreen(
                    product = selectedProduct!!,
                    currentUser = currentUser,
                    onBack = {
                        selectedProduct = null
                        // Refresh products
                        products.clear()
                        products.addAll(DatabaseHelper.getAllProducts())
                    }
                )
                else -> when (currentScreen) {
                    "home" -> HomeScreen(
                        products = products,
                        onProductClick = { selectedProduct = it }
                    )
                    "donasi" -> DonasiScreen(
                        donationPlaces = donationPlaces,
                        onAddPlace = { newPlace ->
                            donationPlaces.add(0, newPlace)
                        }
                    )
                    "jual" -> JualScreen(
                        currentUser = currentUser,
                        onProductAdded = { newProduct ->
                            products.add(0, newProduct)
                        }
                    )
                    "akun" -> AkunScreen(user = currentUser, onLogout = onLogout)
                }
            }
        }
    }
}

// Continue in next artifact...