

package com.example.puterinapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.compose.ui.graphics.Color
import java.text.SimpleDateFormat
import java.util.*

object DatabaseHelper {
  const val DATABASE_NAME = "PuterinApp.db"
    const val DATABASE_VERSION = 1

    private lateinit var dbHelper: PuterinDatabaseHelper

    fun init(context: Context) {
        dbHelper = PuterinDatabaseHelper(context)
    }

    // --- USER OPERATIONS ---

    fun registerUser(name: String, email: String, password: String, phone: String, address: String): Boolean {
        val db = dbHelper.writableDatabase

        // Check if email already exists
        val cursor = db.query(
            "users",
            arrayOf("email"),
            "email = ?",
            arrayOf(email),
            null, null, null
        )

        if (cursor.count > 0) {
            cursor.close()
            return false
        }
        cursor.close()

        val values = ContentValues().apply {
            put("name", name)
            put("email", email)
            put("password", password)
            put("phone", phone)
            put("address", address)
            put("join_date", SimpleDateFormat("MMMM yyyy", Locale("id", "ID")).format(Date()))
        }

        val result = db.insert("users", null, values)
        return result != -1L
    }

    fun loginUser(email: String, password: String): User? {
        val db = dbHelper.readableDatabase
        val cursor = db.query(
            "users",
            null,
            "email = ? AND password = ?",
            arrayOf(email, password),
            null, null, null
        )

        var user: User? = null
        if (cursor.moveToFirst()) {
            user = User(
                id = cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                name = cursor.getString(cursor.getColumnIndexOrThrow("name")),
                email = cursor.getString(cursor.getColumnIndexOrThrow("email")),
                phone = cursor.getString(cursor.getColumnIndexOrThrow("phone")),
                address = cursor.getString(cursor.getColumnIndexOrThrow("address")),
                joinDate = cursor.getString(cursor.getColumnIndexOrThrow("join_date"))
            )
        }
        cursor.close()
        return user
    }

    fun checkEmailExists(email: String): Boolean {
        val db = dbHelper.readableDatabase
        val cursor = db.query(
            "users",
            arrayOf("email"),
            "email = ?",
            arrayOf(email),
            null, null, null
        )
        val exists = cursor.count > 0
        cursor.close()
        return exists
    }

    fun updatePassword(email: String, newPassword: String) {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("password", newPassword)
        }
        db.update("users", values, "email = ?", arrayOf(email))
    }

    // --- PRODUCT OPERATIONS ---

    fun addProduct(
        name: String,
        price: String,
        description: String,
        condition: String,
        seller: String,
        sellerPhone: String
    ): Long {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("name", name)
            put("price", price)
            put("description", description)
            put("condition", condition)
            put("seller", seller)
            put("seller_phone", sellerPhone)
            put("created_at", System.currentTimeMillis())
        }
        return db.insert("products", null, values)
    }

    fun getAllProducts(): List<Product> {
        val products = mutableListOf<Product>()
        val db = dbHelper.readableDatabase
        val cursor = db.query(
            "products",
            null,
            null,
            null,
            null, null,
            "created_at DESC"
        )

        while (cursor.moveToNext()) {
            val productId = cursor.getInt(cursor.getColumnIndexOrThrow("id"))
            products.add(
                Product(
                    id = productId,
                    name = cursor.getString(cursor.getColumnIndexOrThrow("name")),
                    price = cursor.getString(cursor.getColumnIndexOrThrow("price")),
                    description = cursor.getString(cursor.getColumnIndexOrThrow("description")),
                    condition = cursor.getString(cursor.getColumnIndexOrThrow("condition")),
                    seller = cursor.getString(cursor.getColumnIndexOrThrow("seller")),
                    sellerPhone = cursor.getString(cursor.getColumnIndexOrThrow("seller_phone")),
                    reviews = getProductReviews(productId)
                )
            )
        }
        cursor.close()
        return products
    }

    // --- REVIEW OPERATIONS ---

    fun addReview(productId: Int, userName: String, rating: Int, comment: String): Long {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("product_id", productId)
            put("user_name", userName)
            put("rating", rating)
            put("comment", comment)
            put("date", getRelativeTime())
        }
        return db.insert("reviews", null, values)
    }

    fun getProductReviews(productId: Int): MutableList<Review> {
        val reviews = mutableListOf<Review>()
        val db = dbHelper.readableDatabase
        val cursor = db.query(
            "reviews",
            null,
            "product_id = ?",
            arrayOf(productId.toString()),
            null, null,
            "id DESC"
        )

        while (cursor.moveToNext()) {
            reviews.add(
                Review(
                    id = cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                    productId = cursor.getInt(cursor.getColumnIndexOrThrow("product_id")),
                    userName = cursor.getString(cursor.getColumnIndexOrThrow("user_name")),
                    rating = cursor.getInt(cursor.getColumnIndexOrThrow("rating")),
                    comment = cursor.getString(cursor.getColumnIndexOrThrow("comment")),
                    date = cursor.getString(cursor.getColumnIndexOrThrow("date"))
                )
            )
        }
        cursor.close()
        return reviews
    }

    // --- DONATION PLACE OPERATIONS ---

    fun addDonationPlace(
        name: String,
        description: String,
        address: String,
        phone: String,
        category: String
    ): Long {
        val db = dbHelper.writableDatabase
        val values = ContentValues().apply {
            put("name", name)
            put("description", description)
            put("address", address)
            put("phone", phone)
            put("category", category)
        }
        return db.insert("donation_places", null, values)
    }

    fun getAllDonationPlaces(): List<DonationPlace> {
        val places = mutableListOf<DonationPlace>()
        val db = dbHelper.readableDatabase
        val cursor = db.query(
            "donation_places",
            null,
            null,
            null,
            null, null,
            "id DESC"
        )

        val colors = listOf(
            Color(0xFFE57373), Color(0xFF81C784), Color(0xFF64B5F6),
            Color(0xFFFFD54F), Color(0xFFBA68C8), Color(0xFFFF8A65)
        )

        while (cursor.moveToNext()) {
            places.add(
                DonationPlace(
                    id = cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                    name = cursor.getString(cursor.getColumnIndexOrThrow("name")),
                    description = cursor.getString(cursor.getColumnIndexOrThrow("description")),
                    address = cursor.getString(cursor.getColumnIndexOrThrow("address")),
                    phone = cursor.getString(cursor.getColumnIndexOrThrow("phone")),
                    category = cursor.getString(cursor.getColumnIndexOrThrow("category")),
                    imageColor = colors[cursor.getPosition() % colors.size]
                )
            )
        }
        cursor.close()
        return places
    }

    // --- HELPER FUNCTIONS ---

    private fun getRelativeTime(): String {
        return "Baru saja"
    }
}

// --- DATABASE HELPER CLASS ---

private class PuterinDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DatabaseHelper.DATABASE_NAME, null, DatabaseHelper.DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        // Create users table
        db.execSQL("""
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                phone TEXT NOT NULL,
                address TEXT NOT NULL,
                join_date TEXT NOT NULL
            )
        """)

        // Create products table
        db.execSQL("""
            CREATE TABLE products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                price TEXT NOT NULL,
                description TEXT NOT NULL,
                condition TEXT NOT NULL,
                seller TEXT NOT NULL,
                seller_phone TEXT NOT NULL,
                created_at INTEGER NOT NULL
            )
        """)

        // Create reviews table
        db.execSQL("""
            CREATE TABLE reviews (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                user_name TEXT NOT NULL,
                rating INTEGER NOT NULL,
                comment TEXT NOT NULL,
                date TEXT NOT NULL,
                FOREIGN KEY (product_id) REFERENCES products(id)
            )
        """)

        // Create donation_places table
        db.execSQL("""
            CREATE TABLE donation_places (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT NOT NULL,
                address TEXT NOT NULL,
                phone TEXT NOT NULL,
                category TEXT NOT NULL
            )
        """)

        // Insert sample data
        insertSampleData(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS users")
        db.execSQL("DROP TABLE IF EXISTS products")
        db.execSQL("DROP TABLE IF EXISTS reviews")
        db.execSQL("DROP TABLE IF EXISTS donation_places")
        onCreate(db)
    }

    private fun insertSampleData(db: SQLiteDatabase) {
        // Sample products
        val products = listOf(
            ContentValues().apply {
                put("name", "Sepatu Nike")
                put("price", "Rp 450.000")
                put("description", "Sepatu Nike original bekas pakai 3 bulan, kondisi 90%, box lengkap, cocok untuk olahraga dan casual.")
                put("condition", "Bekas - Sangat Baik")
                put("seller", "Andi Pratama")
                put("seller_phone", "081234567890")
                put("created_at", System.currentTimeMillis())
            },
            ContentValues().apply {
                put("name", "Speaker JBL")
                put("price", "Rp 1.200.000")
                put("description", "Speaker JBL Flip 5 waterproof, suara jernih bass mantap, baterai awet 12 jam.")
                put("condition", "Bekas - Seperti Baru")
                put("seller", "Rudi Santoso")
                put("seller_phone", "081234567891")
                put("created_at", System.currentTimeMillis() - 100000)
            },
            ContentValues().apply {
                put("name", "Kemeja Flannel")
                put("price", "Rp 120.000")
                put("description", "Kemeja flannel premium, ukuran L, bahan adem dan nyaman, cocok untuk hangout.")
                put("condition", "Bekas - Baik")
                put("seller", "Toko Preloved")
                put("seller_phone", "081234567892")
                put("created_at", System.currentTimeMillis() - 200000)
            }
        )

        products.forEach { db.insert("products", null, it) }

        // Sample reviews
        db.insert("reviews", null, ContentValues().apply {
            put("product_id", 1)
            put("user_name", "Budi")
            put("rating", 5)
            put("comment", "Barang bagus sesuai deskripsi!")
            put("date", "2 hari lalu")
        })

        db.insert("reviews", null, ContentValues().apply {
            put("product_id", 1)
            put("user_name", "Siti")
            put("rating", 4)
            put("comment", "Kondisi oke, respon penjual cepat")
            put("date", "5 hari lalu")
        })

        db.insert("reviews", null, ContentValues().apply {
            put("product_id", 2)
            put("user_name", "Dewi")
            put("rating", 5)
            put("comment", "Suaranya mantap, packing rapi!")
            put("date", "1 minggu lalu")
        })

        // Sample donation places
        val donationPlaces = listOf(
            ContentValues().apply {
                put("name", "Panti Asuhan Kasih Ibu")
                put("description", "Panti Asuhan - Jl. Mawar No. 10")
                put("address", "Jl. Mawar No. 10, Medan")
                put("phone", "081234567896")
                put("category", "Panti Asuhan")
            },
            ContentValues().apply {
                put("name", "Yayasan Yatim Mandiri")
                put("description", "Yayasan - Jl. Melati No. 45")
                put("address", "Jl. Melati No. 45, Medan")
                put("phone", "081234567897")
                put("category", "Yayasan")
            },
            ContentValues().apply {
                put("name", "Posko Bencana Alam")
                put("description", "Posko Bencana - Kecamatan Sukamaju")
                put("address", "Kecamatan Sukamaju, Medan")
                put("phone", "081234567898")
                put("category", "Posko Bencana")
            }
        )

        donationPlaces.forEach { db.insert("donation_places", null, it) }
    }
}