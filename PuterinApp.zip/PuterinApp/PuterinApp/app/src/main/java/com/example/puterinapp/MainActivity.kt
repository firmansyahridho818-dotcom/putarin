package com.example.puterinapp

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background // <--- INI YANG TADI KURANG
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PuterinAppTheme {
                MainScreen()
            }
        }
    }
}

// --- 1. Struktur Utama (Navigasi Bawah) ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    var currentScreen by remember { mutableStateOf("home") }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("puter.in", fontWeight = FontWeight.Bold, color = Color.White) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color(0xFF1E3A8A)
                )
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") },
                    selected = currentScreen == "home",
                    onClick = { currentScreen = "home" }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Favorite, contentDescription = "Donasi") },
                    label = { Text("Donasi") },
                    selected = currentScreen == "donasi",
                    onClick = { currentScreen = "donasi" }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.AddCircle, contentDescription = "Jual") },
                    label = { Text("Jual") },
                    selected = currentScreen == "jual",
                    onClick = { currentScreen = "jual" }
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Person, contentDescription = "Akun") },
                    label = { Text("Akun") },
                    selected = currentScreen == "akun",
                    onClick = { currentScreen = "akun" }
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (currentScreen) {
                "home" -> HomeScreen()
                "donasi" -> DonasiScreen()
                "jual" -> JualScreen()
                "akun" -> AkunScreen()
            }
        }
    }
}

// --- 2. Halaman HOME ---
@Composable
fun HomeScreen() {
    val products = listOf(
        "Sepatu Nike" to "Rp 450.000",
        "Speaker JBL" to "Rp 1.200.000",
        "Kemeja Flannel" to "Rp 120.000",
        "Jam Casio" to "Rp 300.000",
        "Tas Eiger" to "Rp 250.000",
        "Laptop Asus" to "Rp 3.500.000"
    )

    Column(modifier = Modifier.padding(16.dp)) {
        OutlinedTextField(
            value = "",
            onValueChange = {},
            label = { Text("Cari barang bekas...") },
            modifier = Modifier.fillMaxWidth(),
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            shape = MaterialTheme.shapes.medium
        )

        Spacer(modifier = Modifier.height(16.dp))
        Text("Rekomendasi", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(modifier = Modifier.height(8.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(products) { (name, price) ->
                ProductCard(name, price)
            }
        }
    }
}

@Composable
fun ProductCard(name: String, price: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(4.dp)) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(modifier = Modifier.size(100.dp), color = Color.LightGray, shape = MaterialTheme.shapes.small) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = Color.Gray)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(name, fontWeight = FontWeight.Medium)
            Text(price, color = Color(0xFF1E3A8A), fontWeight = FontWeight.Bold)
        }
    }
}

// --- 3. Halaman JUAL ---
@Composable
fun JualScreen() {
    Column(
        modifier = Modifier
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Jual Barang Bekas", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E3A8A))
        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth().height(150.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF3F4F6))
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(40.dp), tint = Color.Gray)
                Text("Tap untuk upload foto", color = Color.Gray)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(value = "", onValueChange = {}, label = { Text("Judul Barang") }, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(value = "", onValueChange = {}, label = { Text("Harga (Rp)") }, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = "", onValueChange = {}, label = { Text("Deskripsi") },
            modifier = Modifier.fillMaxWidth().height(100.dp),
            maxLines = 5
        )
        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = {},
            modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488))
        ) {
            Text("Tayangkan Iklan")
        }
    }
}

// --- 4. Halaman DONASI (YANG BARU) ---

// Model Data Sederhana
data class DonationPlace(
    val name: String,
    val description: String,
    val imageColor: Color
)

@Composable
fun DonasiScreen() {
    // State untuk mengatur navigasi internal (List -> Form)
    var selectedPlace by remember { mutableStateOf<DonationPlace?>(null) }
    val context = LocalContext.current // Memperbaiki konteks agar Toast bisa muncul

    // Data Dummy Panti Asuhan/Tempat Donasi
    val donationPlaces = listOf(
        DonationPlace("Panti Asuhan Kasih Ibu", "Jl. Mawar No. 10", Color(0xFFE57373)),
        DonationPlace("Yayasan Yatim Mandiri", "Jl. Melati No. 45", Color(0xFF81C784)),
        DonationPlace("Posko Bencana Alam", "Kecamatan Sukamaju", Color(0xFF64B5F6)),
        DonationPlace("Masjid Al-Ikhlas", "Renovasi Masjid", Color(0xFFFFD54F))
    )

    if (selectedPlace == null) {
        // TAMPILAN 1: LIST TEMPAT DONASI
        DonasiListContent(
            places = donationPlaces,
            onItemClick = { place -> selectedPlace = place }
        )
    } else {
        // TAMPILAN 2: FORM PENGISIAN (Setelah diklik)
        DonasiFormContent(
            place = selectedPlace!!,
            onBack = { selectedPlace = null },
            onSubmit = {
                // TAMPILAN 3: SIMULASI KIRIM KE ADMIN
                Toast.makeText(
                    context,
                    "Data berhasil dikirim ke Admin! Admin akan segera menghubungi WA Anda.",
                    Toast.LENGTH_LONG
                ).show()

                // Kembali ke menu awal setelah kirim
                selectedPlace = null
            }
        )
    }
}

// Komponen Tampilan List Donasi
@Composable
fun DonasiListContent(places: List<DonationPlace>, onItemClick: (DonationPlace) -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1E3A8A)) // <-- Ini yang tadi error, sekarang sudah aman
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("Pilih Tujuan Donasi", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        // Grid List
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(places) { place ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        // Gambar Placeholder
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp)
                                .background(place.imageColor), // Aman
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Home, contentDescription = null, tint = Color.White, modifier = Modifier.size(40.dp))
                        }

                        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(place.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
                            Text(place.description, fontSize = 12.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { onItemClick(place) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A)),
                                modifier = Modifier.fillMaxWidth().height(36.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("Donasi", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// Komponen Tampilan Form Donasi
@Composable
fun DonasiFormContent(place: DonationPlace, onBack: () -> Unit, onSubmit: () -> Unit) {
    var nama by remember { mutableStateOf("") }
    var noHp by remember { mutableStateOf("") }
    var alamat by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // Header Form
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1E3A8A)) // Aman
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Text("Konfirmasi Pengiriman", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }

        Column(modifier = Modifier.padding(20.dp)) {
            // Info Tujuan
            Text("Tujuan Donasi:", color = Color.Gray, fontSize = 12.sp)
            Text(place.name, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF1E3A8A))
            Spacer(modifier = Modifier.height(24.dp))

            // Form Input
            Text("Data Pengirim Donasi", fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = nama, onValueChange = { nama = it },
                label = { Text("Nama Lengkap") },
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
            )
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = noHp, onValueChange = { noHp = it },
                label = { Text("Nomor HP / WA") },
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) }
            )
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = alamat, onValueChange = { alamat = it },
                label = { Text("Alamat Pengambilan") },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 3,
                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) }
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Area Upload Foto (Simulasi)
            Text("Foto Barang Donasi", fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .background(Color(0xFFF0F0F0), shape = MaterialTheme.shapes.medium) // Aman
                    .padding(2.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(40.dp))
                    Text("Tap untuk upload foto barang", color = Color.Gray, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Button Kirim
            Button(
                onClick = onSubmit,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E3A8A))
            ) {
                Text("Kirim Data ke Admin", fontWeight = FontWeight.Bold)
            }
        }
    }
}

// --- 5. Halaman AKUN ---
@Composable
fun AkunScreen() {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(80.dp), tint = Color.Gray)
        Text("Nama User", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("user@example.com", color = Color.Gray)
    }
}

@Composable
fun PuterinAppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF1E3A8A),
            secondary = Color(0xFF0D9488)
        ),
        content = content
    )
}